package stsfan.com.kotlinstu.kotlinmvp

import android.graphics.ColorSpace
import java.lang.ref.SoftReference

open class KtPresenter(val mview: KtActivity) :Contract.Ipresenter{
      var  soft:SoftReference<Contract.Imodel>?=null
    //private var mUserPresenter: UserPresenter? = null
    //?可为空
     var ktac:KtActivity? = null
    override fun Attch(miview: Contract.Iview) {
         var  mmodel:KtModel ?= KtModel()
        ktac= KtActivity()
        //软引用
        soft = SoftReference<Contract.Imodel>(mmodel)


    }

    override fun Decth() {
        if (ktac!=null){
            ktac==null
        }
    }


    override fun GetPersnetViewDate(page:Int,count:Int) {
        //!!表示对象不为空的情况下去执行
        soft!!.get()!!.GetModelDate(page,count,object:Contract.Imodel.ModelCallBack{
            override fun onSuccess(mttbena: KtBean) {
                ktac!!.GetViewDate(mttbena)

            }

            override fun onFails() {
            }
        })

    }
}