package stsfan.com.kotlinstu.kotlinmvp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import stsfan.com.kotlinstu.R
import javax.security.auth.login.LoginException

open  class KtActivity: AppCompatActivity() ,Contract.Iview{
      var ktpresenter:KtPresenter ?=null
    override fun GetViewDate(mktbean:KtBean) {

        Log.i("kt==",mktbean.toString())

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kt)
        ktpresenter= KtPresenter(this)
        ktpresenter!!.Attch(this)
        ktpresenter!!.GetPersnetViewDate(1,10)

    }
}
