package stsfan.com.kotlinstu

import kotlin.reflect.KProperty

open class Person {
    lateinit var  name:String
    //lateinit 只用于变量 var，而 lazy 只用于常量 val
    //次构造器
     constructor (name: String){
        println("$name")

    }
    open fun pens(name: String) {
        println("${name}教育")

    }
  //内部嵌套类

    inner  class son{
         val  foodw:String? = "面包"
         var  eate:String?="吃"
         var  namesd:String="小明"

         fun  love(names: String,food:String,eat:String){
             println(names+eat+food)

         }
     }
    class soner{
        val  foodw:String? = "面包"
        var  eate:String?="吃"
        var  namesd:String="小明"

        fun  love(names: String,food:String,eat:String){
            println(names+eat+food)

        }
    }

}

fun main(args: Array<String>) {
    println("dhhh")
    //次构造器
    var  person=Person("小花爱笑")
    //内部嵌套
    var  sons=Person("小花爱笑").son()
    //嵌套类
    Person.soner().love("小黑","黑豆","吃")

    sons.love("小王","闷到马户","喝")


    person.pens(sons.namesd)


    println(sons.namesd+sons.eate+sons.foodw)

}








