package stsfan.com.kotlinstu.utils

import io.reactivex.Observable
import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Query
import stsfan.com.kotlinstu.kotlinmvp.KtBean

interface NetWorkUtils {
   //
    @GET("findReleaseMovieList")
     fun getNetDate(@Query("page")page:Int,@Query("count")count:Int):Observable<KtBean>

}