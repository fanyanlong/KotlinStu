package stsfan.com.kotlinstu.kotlinmvp

import java.util.*

interface Contract {
          //Iview
       interface  Iview{
             fun GetViewDate(mktbean:KtBean)
          }
         // Ipresenter
         interface  Ipresenter{
             fun GetPersnetViewDate(page:Int,count:Int)
             fun  Attch(miview:Iview)
             fun  Decth()
         }

      // Imodel
      interface  Imodel{
          fun GetModelDate(page:Int,count:Int,model:ModelCallBack)
          interface ModelCallBack {
                 fun  onSuccess(mttbena:KtBean)
                 fun  onFails()
          }
      }
}


