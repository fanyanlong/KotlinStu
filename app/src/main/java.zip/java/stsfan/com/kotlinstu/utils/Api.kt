package stsfan.com.kotlinstu.utils

open  class Api{
      companion object {
          var BaseUrl:String="http://172.17.8.100/movieApi/movie/v1/"
      }


}