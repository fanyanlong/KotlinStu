package stsfan.com.kotlinstu.kotlinmvp

data class KtBean(
    val message: String,
    val result: List<Result>,
    val status: String
)

data class Result(
    val followMovie: Boolean,
    val id: Int,
    val imageUrl: String,
    val name: String,
    val rank: Int,
    val summary: String
)